package com.capgemini.flp.dao;

import com.capgemini.flp.exception.LoginException;


public interface ILoginDAO {

	/*public AdminLogin login(AdminLogin login);
	public boolean loginVerifier(String email, String password);*/
	public boolean findUser(String emailId,String password) throws LoginException;
}
