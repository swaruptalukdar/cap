package com.capgemini.flp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.model.AdminLogin;
import com.capgemini.flp.service.ILoginService;

/*@Controller
public class LoginController {
	@Autowired
	private ILoginService service;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public  String showLoginForm() {
		return "userLogin";
	}
	
	
	@RequestMapping(value="/adminlogin",method=RequestMethod.GET)
	public  void loginVerifier(@RequestParam("email") String email,@RequestParam("password") String pass) {
		 service.loginVerifier(email,pass);
		 
	}	
}*/






@Controller

public class LoginController {
	
	@Autowired
	private ILoginService service;
	@RequestMapping(value="/login")
	
	public ModelAndView viewLogin() {
		return new ModelAndView("userLogin","user",new AdminLogin());
	}
	
	@RequestMapping(value="/verify", method=RequestMethod.POST)
	public String doLogin( @Valid @ModelAttribute("user") AdminLogin user,
			/*BindingResult result,*/ HttpServletRequest request, Model model){
		try {
			
			/*if(result.hasErrors()) {
				List<ObjectError> errorList=result.getAllErrors();
				System.out.println(errorList);
				return "userLogin";
			}else {*/
				if(isValidCredential(user.getEmailId(),user.getPassword())) {
					HttpSession session= request.getSession();
					session.setAttribute("emailId", user.getEmailId());
					return "main_menu";
				}else{
					/*model.addAttribute("message","Invalid Credentials");
					return "status";*/
				}
			//}
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		/*model.addAttribute("status","Invalid Credentials");*/
		return null;
	}

	private boolean isValidCredential(String emailId, String password) {
		boolean flag=false;
		try {
			
			boolean b= service.findUser(emailId, password);
			if(b) {
				flag=true;
			}else {
				flag=false;	}
		}catch(LoginException e) {
			System.err.println(e.getMessage());
			
		}
		
		return flag;
	}
}
				
	