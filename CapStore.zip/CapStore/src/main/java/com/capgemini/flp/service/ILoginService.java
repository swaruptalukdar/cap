package com.capgemini.flp.service;

import com.capgemini.flp.exception.LoginException;

public interface ILoginService {

	/*boolean loginVerifier(String email, String pass);*/
	public boolean findUser(String emailId,String password) throws LoginException;

}
