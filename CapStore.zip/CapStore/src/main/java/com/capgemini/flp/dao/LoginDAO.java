package com.capgemini.flp.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.model.AdminLogin;
@Repository
public class LoginDAO implements ILoginDAO{

	@PersistenceContext
	EntityManager entityManager;
/*
	@Override
	public AdminLogin login(AdminLogin login) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean loginVerifier(String email, String password) {
		
			AdminLogin user=entityManager.find(AdminLogin.class,email);
			System.out.println(user);
			return false;
			
	}
		*/
	
	@Override
	public boolean findUser(String emailId, String password)
			throws LoginException {
		boolean flag=false;
		try{
		AdminLogin user=entityManager.find(AdminLogin.class, emailId);
		if(user != null)
		{
			if(user.getPassword().equals(password)){
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		else
		{
			flag=false;
		}
		}catch(PersistenceException e){
			throw new LoginException(e.getMessage());
		}
		return flag;
	}
	}


